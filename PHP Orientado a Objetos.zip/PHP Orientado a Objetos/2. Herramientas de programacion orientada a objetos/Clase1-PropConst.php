<?php

class Config{

    /*
    const DB_USER_NAME = 'ReoNa';
    const DB_USER_PASSWORD = 'Anima';
    const DB_DATABASE_NAME = 'Db_Anima';
    */
}

class BaseProfile extends Config{

    protected $connection_data = 'Conexion BD';
    protected function connect2DB(){

        if('production' == self::ENVIRONMENT){

            echo 'Conectando a produccion';
        }

        if('development' == self::ENVIRONMENT){

            echo 'Conectando a desarrollo';
        }

        if('staging' == self::ENVIRONMENT){

            echo 'Conectando a staging';
        }
    }

    public function __construct(){

        $this->connect2DB;
    }
}

class MyProfile extends BaseProfile{

    const DOMAIN_NAME = 'ReoNaredsocial.com';
    private $email = 'ReoNa@correo.com';
    public $bname;
    public $last_name;

    public function __construct(){

        $this->connect2DB();
    }

    public function getEmail(){

        return $this->email;
    }

    public function setEmail($email){

        $this->email = $email;
    }

    public function message(){

        echo "Mensaje";
    }

}




?>