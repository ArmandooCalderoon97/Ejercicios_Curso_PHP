<?php

class Indesctructible{

    public function __construct(){

        print "Clase creada\n";
        $this->name = "Indesctructible";
    }

    public function __destruct(){

        print "Destruyendo a " . $this->name . "\n";
    }
}

$instIndesctructible = new Indesctructible();
unset($instIndesctructible);

for($i = 0; $i < 100; $i++){

    echo "{$i} \n";

}


?>