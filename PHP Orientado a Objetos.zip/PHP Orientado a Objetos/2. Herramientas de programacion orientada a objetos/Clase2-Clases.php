<?php

abstract class Animal{

    abstract public function makeSound();

    public function run(){

        echo "Corriendo\n";
    }
}

class Gallo extends Animal{

    public function makeSound(){
    
        echo "Kokoroko\n";
    }
}

class Vaca extends Animal{

    public function makeSound(){

        echo "Muuuuuu\n";
    }
}

interface iDB{

    public function connect();
}

class MySQL implements iDB{

    public function connect(){

        echo "Conectando con MySQL\n";
    }

}

class Oracle implements iDB{

    public function connect(){

        echo " Conectando con Oracle\n";
    }
}

$insDog = new Gallo;
$instCat = new Vaca;
$insDog->makeSound();
$insDog->run();
$instCat->makeSound();
$instCat->run();

$instMySQL = new MySQL;
$instOracle = new Oracle;

$instMySQL->connect();
$instOracle->connect();

?>