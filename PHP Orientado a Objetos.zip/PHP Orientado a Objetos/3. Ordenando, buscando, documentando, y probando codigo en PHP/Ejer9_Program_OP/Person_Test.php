<?php

require_once('person.php');
class PersonTest extends PHPUnit_Framework_TestCase{

    public function testPersonConstrucut(){

        $person = new Person('Roberto', 'Calderon');
        $this->assertTrue($person instanceof Person, 'It should be instance of class person');
        $this->assertTrue($person->getName() == 'Roberto', 'It should be Roberto');
        $this->assertTrue($person->getFamilyName() == 'Calderon', 'It should be Calderon');
    }


    public function testEmptyName(){

        $person2 = new Person('Roberto', 'Calderon');
    }
}



?>