<?php
class Posts
{

    public function greet()
    {
        echo "Como estas";
    }
}

?>