<?php
require_once('Posts.php');

class Main 
{

    public $posts;

    public function __construct()
    {
        $this->posts = new Posts;
    }
}

$app = new Main();
$app->posts->greet();

?>