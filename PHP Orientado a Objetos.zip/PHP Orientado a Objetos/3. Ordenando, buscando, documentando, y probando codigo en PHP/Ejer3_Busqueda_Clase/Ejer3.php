<?php
trait myUtilities
{
    function sayMyName()
    {
        echo "Mi nombre es" . $this->name . "\n";
    }
}

abstract class Animal{

    abstract public function makeSound();

    public function run(){

        echo "Corriendo\n";
    }
}

class Dog extends Animal{

    use myUtilities;
    public $name = "Ringo";

    public function makeSound(){

        echo "Guau\n";
    }
}

class Cat extends Animal{
    use myUtilities;
    public $name = "Meliodas";

    public function makeSound(){
        
        echo "Miau\n";
    }
}

$classes = ['Being', 'Animal', 'Plant', 'Dog', 'Cat', 'Mouse', 'Cactus'];

foreach($classes as $class_)
{
    echo $class_ . (class_exists($class_)? 'Si' : 'No') . "\n";
}

?>