<?php

namespace MyNamespace;
class Myclass 
{
    public function greet()
    {
        echo 'Hola, Como estas';
    }
}

?>