<?php

class Config
{
    const ENVIRONMENT = 'staging';
}

?>